using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace AnekParser
{
    public static class SentenceParser
    {
        static char[] delim = { '.', '!', '?', ';', ':', '(', ')' };

        private static List<string> ParseWords(string sentence)
            => Regex.Matches(sentence, @"[\p{L}|']+").Select(m => m.Value).ToList();

        public static List<List<string>> ParseSentences(string text)
            => text.Split(delim).Select(s => ParseWords(s)).Where(l => l.Count != 0).ToList();
    }
}